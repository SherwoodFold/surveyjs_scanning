function init() {
  Survey.StylesManager.applyTheme("default");
}
document.addEventListener("DOMContentLoaded", init);