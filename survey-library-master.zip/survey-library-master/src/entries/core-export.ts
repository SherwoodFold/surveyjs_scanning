export { SurveyModel, SurveyWindowModel } from "survey-core";
export { settings } from "survey-core";
export { surveyLocalization, surveyStrings } from "survey-core";
