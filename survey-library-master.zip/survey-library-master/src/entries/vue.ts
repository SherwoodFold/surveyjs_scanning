export * from "./core";

// themes settings
export * from "./plugins";

// localization
import "./chunks/localization";

export * from "./vue-ui-model";
